decklist
========

The code behind decklist.org, which generates DCI Registration Sheets.
