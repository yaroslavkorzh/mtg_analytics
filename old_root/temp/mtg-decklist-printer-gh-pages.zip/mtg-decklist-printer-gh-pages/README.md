# MtG: Little decklist printer

> Just a simple decklist printer, generating decklist that fits in a card sleeve.

* * *

Simply enter your decklist in the form, then click the print button to print a decklist that can fit in a card sleeve.

*(This tool has been tested on some printers with success, but the result is not guaranteed - it's just a tiny tool.)*

* * *

Made by [leny](http://leny.me).

Don't hesitate to fork, modify, and/or do anything you want with this.
