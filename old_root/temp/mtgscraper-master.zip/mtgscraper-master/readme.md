# Deck Scraper From Various Places
Scrapes decklists from:

- [ ] - Starcity Games
- [ ] - Dailies
- [ ] - TCGPlayer